"""Project-wide constants for sarand."""

from __future__ import annotations

from pathlib import Path

# There is no fixed default project. sarand always analyses the
# current working directory unless --project is given.
# هیچ پروژه پیش‌فرض ثابتی وجود ندارد. sarand همیشه دایرکتوری فعلی را
# تحلیل می‌کند مگر اینکه --project داده شود.

DEFAULT_OUTPUT_DIR = Path.home() / "Downloads"

MAX_TREE_DEPTH = 8
MAX_TREE_ENTRIES = 100
MAX_FILE_SIZE = 2 * 1024 * 1024
MAX_ISSUE_ROWS = 500
HASH_MAX_BYTES = 512 * 1024
MAX_HASH_FILES = 5000

IGNORE_DIRS: frozenset[str] = frozenset(
    {
        ".git",
        ".venv",
        "venv",
        "__pycache__",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        ".cache",
        "target",
        "build",
        "dist",
        "node_modules",
        ".tox",
        ".eggs",
        ".idea",
        ".vscode",
        ".sarand-cache",
    }
)

ESSENTIAL_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".py",
        ".rs",
        ".toml",
        ".json",
        ".yaml",
        ".yml",
        ".md",
        ".txt",
        ".lock",
        ".sh",
        ".bash",
        ".zsh",
        ".ini",
        ".cfg",
        ".conf",
        ".proto",
        ".c",
        ".h",
        ".cpp",
        ".hpp",
        ".go",
        ".js",
        ".ts",
        ".jsx",
        ".tsx",
        ".java",
        ".kt",
        ".kts",
        ".xml",
        ".gradle",
        ".properties",
        ".lua",
        ".rockspec",
        ".rb",
        ".gemspec",
        ".php",
        ".dart",
        ".css",
        ".scss",
        ".less",
        ".zig",
        ".swift",
        ".sql",
        ".cs",
        ".r",
        ".pl",
        ".pm",
        ".jl",
        ".m",
        ".mm",
        ".groovy",
        ".ps1",
        ".psm1",
        ".psd1",
        ".nix",
    }
)

LANG_MAP: dict[str, str] = {
    ".py": "python",
    ".rs": "rust",
    ".toml": "toml",
    ".json": "json",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".md": "markdown",
    ".sh": "bash",
    ".bash": "bash",
    ".zsh": "bash",
    ".proto": "protobuf",
    ".c": "c",
    ".h": "c",
    ".cpp": "cpp",
    ".hpp": "cpp",
    ".go": "go",
    ".js": "javascript",
    ".ts": "typescript",
    ".jsx": "jsx",
    ".tsx": "tsx",
    ".java": "java",
    ".kt": "kotlin",
    ".kts": "kotlin",
    ".xml": "xml",
    ".gradle": "groovy",
    ".lua": "lua",
    ".rockspec": "lua",
    ".rb": "ruby",
    ".gemspec": "ruby",
    ".php": "php",
    ".dart": "dart",
    ".css": "css",
    ".scss": "scss",
    ".less": "less",
    ".zig": "zig",
    ".swift": "swift",
    ".sql": "sql",
    ".cs": "csharp",
    ".r": "r",
    ".pl": "perl",
    ".pm": "perl",
    ".jl": "julia",
    ".m": "objectivec",
    ".mm": "objectivec",
    ".groovy": "groovy",
    ".ps1": "powershell",
    ".psm1": "powershell",
    ".psd1": "powershell",
    ".nix": "nix",
}

WARNING_PATTERNS: tuple[str, ...] = ("warning:", "warning[", "deprecated", "unused")
ERROR_PATTERNS: tuple[str, ...] = (
    "error:",
    "failed",
    "traceback",
    "panic",
    "exception",
)

KNOWN_ISSUE_PATTERNS: list[tuple[str, str]] = [
    ("Failed to parse", "One or more source files contain syntax errors."),
    ("ModuleNotFoundError", "A required Python dependency is missing."),
    ("error:", "Compilation or lint errors were detected."),
]

TODO_PATTERNS: tuple[str, ...] = ("TODO", "FIXME", "BUG", "HACK", "SAFETY", "XXX")

AI_NOTICE = (
    "This report is generated for AI analysis and contains project metadata, "
    "test results and source files."
)

DEFAULT_CMD_TIMEOUT = 300
LONG_CMD_TIMEOUT = 3600

# Marker files used for project/language discovery, in priority order.
# فایل‌های نشانگر برای تشخیص پروژه/زبان، به ترتیب اولویت.
PROJECT_MARKERS: dict[str, tuple[str, str, str]] = {
    "Cargo.toml": ("Rust", "binary/library", "cargo"),
    "pyproject.toml": ("Python", "package", "pip/poetry/uv"),
    "setup.py": ("Python", "package", "setuptools"),
    "setup.cfg": ("Python", "package", "setuptools"),
    "requirements.txt": ("Python", "application", "pip"),
    "package.json": ("Node.js", "application", "npm"),
    "go.mod": ("Go", "module", "go"),
    "CMakeLists.txt": ("C/C++", "binary/library", "cmake"),
    "pom.xml": ("Java", "application", "maven"),
    "build.gradle": ("Java/Kotlin", "application", "gradle"),
    "build.gradle.kts": ("Java/Kotlin", "application", "gradle"),
    "Makefile": ("Generic", "unknown", "make"),
    "init.lua": ("Lua", "module/library", "none"),
    "Gemfile": ("Ruby", "application/gem", "bundler"),
    "composer.json": ("PHP", "application/package", "composer"),
    "pubspec.yaml": ("Dart/Flutter", "application/package", "pub"),
    "tsconfig.json": ("TypeScript", "application/library", "npm/tsc"),
    "build.zig": ("Zig", "binary/library", "zig"),
    "Package.swift": ("Swift", "application/library", "swift package manager"),
    "DESCRIPTION": ("R", "package", "renv (optional)"),
    "cpanfile": ("Perl", "application/module", "cpanm"),
    "Project.toml": ("Julia", "package", "Pkg"),
}

ENTRY_POINT_CANDIDATES: dict[str, tuple[str, ...]] = {
    "Rust": ("src/main.rs", "src/lib.rs"),
    "Python": ("src/main.py", "main.py", "cli.py", "__main__.py", "app.py"),
    "Node.js": ("index.js", "src/index.js", "server.js", "src/index.ts"),
    "Go": ("main.go", "cmd/main.go"),
    "Java/Kotlin": ("src/main/java", "src/main/kotlin"),
    "C/C++": ("src/main.cpp", "src/main.c", "main.cpp", "main.c"),
    "Lua": ("init.lua", "main.lua", "app.lua", "src/main.lua", "src/init.lua"),
    "Ruby": ("main.rb", "app.rb", "lib/main.rb"),
    "PHP": ("public/index.php", "index.php", "src/index.php"),
    "Dart/Flutter": ("lib/main.dart", "bin/main.dart"),
    "TypeScript": ("src/index.ts", "src/main.ts", "index.ts"),
    "Zig": ("src/main.zig", "build.zig"),
    "Swift": ("Sources/main.swift", "main.swift"),
    "R": ("R/main.R", "main.R", "app.R"),
    "Perl": ("bin/app.pl", "script/app.pl", "main.pl"),
    "Julia": ("src/main.jl", "main.jl"),
}

# Filename patterns that must NEVER be embedded in a generated report,
# regardless of extension (AGENTS.md §4.10). Matched against the
# lowercased filename only, not the full path -- a file named
# "id_rsa" three directories deep is exactly as dangerous as one at
# the root.
# الگوهای نام فایلی که هرگز نباید در گزارش تولیدشده درج شوند، فارغ از
# پسوند (§4.10 در AGENTS.md). فقط با نام فایل (حروف‌کوچک‌شده) مطابقت
# داده می‌شود، نه کل مسیر -- فایلی به نام "id_rsa" در سه پوشه‌ی پایین‌تر
# دقیقاً به‌همان اندازه‌ی نمونه‌ی ریشه خطرناک است.
SECRET_FILENAME_PATTERNS: tuple[str, ...] = (
    r"^id_rsa$",
    r"^id_dsa$",
    r"^id_ecdsa$",
    r"^id_ed25519$",
    r"\.pem$",
    r"\.key$",
    r"\.pfx$",
    r"\.p12$",
    r"^\.env($|\..+$)",
    r"service.?account.*\.json$",
    r"credentials.*\.json$",
    r"^\.npmrc$",
    r"^\.netrc$",
    r"^local\.properties$",
    r"\.jks$",
    r"\.keystore$",
    r"^google-services\.json$",
)
